#token
#===============
token = "5404188625:AAHu0jSZomF6oRd27OnIJyW1jSZJPkyXfOU"
#===================
#chatId
#====================
chatAdmin = "-634670824"
chatAlert = "-1001701966409"
#=====================
#chatLink
#=====================
chatAdminLink = "pass"
chatAlertLink = "pass"
#=====================
#admin
#=====================
admins = [774135114]
coder = [1949809780]
#=====================