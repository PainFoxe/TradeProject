#import databases
import sqlite3

from main import callback


def sqlConnect():
    db = sqlite3.connect('users.db')
    sql = db.cursor()
    db.commit()
    try:
        print("connect access")
    except:
        print("connect decline")
    